import os
from neuron import h

import tornado.ioloop
import tornado.web
import tornado.websocket
import json
import numpy

import collections
import six
import copy

# python 3.8+ compatibility
try:
    collectionsAbc = collections.abc
except:
    collectionsAbc = collections

import sciunit
from sciunit import Capability

def update_parameters_dict(d, u):
    for k, v in six.iteritems(u):
        dv = d.get(k, {})
        if not isinstance(dv, collectionsAbc.Mapping):
            d[k] = v
        elif isinstance(v, collectionsAbc.Mapping):
            d[k] = update_parameters_dict(dv, v)
        else:
            d[k] = v
    return d

class BlueNaaS_Python_Model(sciunit.Capability):

    def get_model_path(self):
        raise NotImplementedError()

    def get_default_parameters(self):
        raise NotImplementedError()

    def get_default_config(self):
        raise NotImplementedError()

    def get_socket_port(self):
        raise NotImplementedError()

    def initialize(self):
        sciunit.Model.__init__(self)

        model_path, mod_files_path = self.get_model_path()
        if not model_path:
            raise ValueError("Please specify the path to the model's file!")

        self.model_path = os.path.abspath(model_path)
        if mod_files_path:
            self.mod_files_path = os.path.abspath(mod_files_path)
        else:
            self.mod_files_path = os.path.abspath(os.path.dirname(self.model_path))
        self.lib_path = "x86_64/.libs/libnrnmech.so.0" # path to mechanisms once compiled; change if required
        self.compile_load_mod_files()
        global_env = {}
        local_env = {}
        exec(open(self.model_path).read(), global_env, local_env)
        for key, value in local_env.items():
            setattr(self, key, value)

        parameters = self.get_default_parameters()
        if parameters:
            self.default_parameters = parameters
        self.apply_parameters(self.default_parameters)
        config = self.get_default_config()
        self.config = config

    def compile_load_mod_files(self):
        if not os.path.isfile(os.path.join(self.mod_files_path, self.lib_path)):
            os.system("cd " + self.mod_files_path + "; nrnivmodl")
            h.nrn_load_dll(str(os.path.join(self.mod_files_path, self.lib_path)))

    def apply_parameters(self, parameters=None):
        if not parameters:
            parameters = self.default_parameters
        for key, value in parameters.items():
            for param, param_value in value.items():
                if "[" in key:  # to handle arrays
                    ind = key.find("[")
                    param_name = key[:ind]
                    param_index = key[ind:]
                    exec("ref = getattr(self, '{}'){}".format(param_name, param_index))
                else:
                    ref = getattr(self, key)
                setattr(ref, param, param_value)

    def apply_config(self, config=None):
        if not config:
            config = self.config
        for key, value in config.items():
            setattr(h, key, value)

    def run_simulation(self, config=None):
        self.apply_config(config=config)
        h.init()
        h.finitialize(h.v_init)
        h.run(h.tstop)

    def get_data(self):
        data_v = {'x':self.t.to_python(), 'y':self.v.to_python(), 'mode':'lines', 'name':'v(0.5)'}
        data_cai = {'x':self.t.to_python(), 'y':self.cai.to_python(), 'mode':'lines', 'name':'cai(0.5)'}
        data = [data_v, data_cai]
        return data

    def setup_socket(self):
        port_number = self.get_socket_port()
        if not port_number:
            raise ValueError("Please specify a port number for web socket!")
        self.port = port_number
        self.app = tornado.web.Application([
            (r'/socket', WebSocketHandler, {'model':self}),
            (r"/(.*)", tornado.web.StaticFileHandler, {"path":r"www/"})
            ])
        self.app.listen(self.port)
        tornado.ioloop.IOLoop.instance().start()


class IndexHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        print("indexhandler::get")
        self.render('index.html')


class WebSocketHandler(tornado.websocket.WebSocketHandler):

    clients = {}
    client_count = 0

    def initialize(self, model):
        self.model = model

    def open(self, *args):
        WebSocketHandler.client_count += 1
        print("websockethandler::open")
        self.id = WebSocketHandler.client_count
        WebSocketHandler.clients[self.id] = self
        self.send_message({'command': 'setfields', 'data': self.model.default_parameters})

    def on_message(self, message):
        message = json.loads(message)
        command = message['command']
        if command == 'setfields':
            parameters = message.get("parameters", {})
            model_parameters = copy.deepcopy(self.model.default_parameters)
            model_parameters = update_parameters_dict(model_parameters, parameters)
            # parameters = {}
            # for name, val in message.iteritems():
            #     if name in self.model.default_parameters:
            #         parameters[name] = val
            self.model.apply_parameters(parameters)
            self.send_message_to_all({'command': 'setfields', 'data': parameters})
        elif command == 'run_simulation':
            parameters = message["parameters"]
            model_parameters = copy.deepcopy(self.model.default_parameters)
            self.model.apply_parameters(parameters)
            self.model.run_simulation()
            sim_output = self.model.get_data()
            # update the line graph
            self.send_message_to_all({'command': 'setgraph', 'data': sim_output})
        else:
            print("message received")
            print(message)

    def on_close(self):
        print("websockethandler::on_close")
        if self.id in WebSocketHandler.clients:
            # remove client from the "list" of clients to notify on change
            del WebSocketHandler.clients[self.id]

    def send_message(self, message):
        self.write_message(json.dumps(message))

    def send_message_to_all(self, message):
        for client in WebSocketHandler.clients.values():
            client.send_message(message)
