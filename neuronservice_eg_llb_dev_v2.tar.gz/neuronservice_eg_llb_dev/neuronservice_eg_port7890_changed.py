import sciunit
import bluenaas_capabilities as cap

# 1. provide main model python file path
model_path = "./themodel_eg.py"

# 2. path to mod files; can be 'None' if mod files in base directory of `model_path`
mod_files_path = None

# 3. Set default values for model parameters (used to reset model to initial state)
# Note: should use same name as target parameter name; so e.g. not gkm for gbar_kmb
default_parameters = {'soma' : {'gbar_kmb':  0.005, 'gcanbar_can': 0.6},
                      'stim[0]' : {'amp' : 0.03}}

# 4. Parameters to be set for NEURON simulator
config = {'tstop' : 600, 'v_init' : -80}

# 5. Specify port number for socket
port_number = 7890

class model_eg_loader(sciunit.Model,
                      cap.BlueNaaS_Python_Model):
    def get_model_path(self):
        return model_path, mod_files_path

    def get_default_parameters(self):
        return default_parameters

    def get_default_config(self):
        return config

    def get_socket_port(self):
        return port_number

model = model_eg_loader()
model.initialize()
model.setup_socket()
