/*
 * Communication section
 */
var ws = new WebSocket('ws://' + window.location.origin.split('//')[1] + '/socket');

var graph_callback = function(msg) {};
var graph_callback_user = function(msg) {};
var shapeplot_callback = function(msg) {};


function onready() {
    var margin = {
            l: 60,
            r: 25,
            b: 60,
            t: 35,
            pad: 15
        }

    var plotlyChart_01 = document.getElementById("plotlyChart_01");
    var plotlyChart_02 = document.getElementById("plotlyChart_02");

    var layout_01= {
        title: 'Voltage',
        xaxis:{title:'t (ms)'},
        yaxis:{title:'V (mV)'},
        legend: { "orientation":"h", y:-0.2 },
        margin: margin,
    };
    var layout_02= {
        title: 'Cai',
        xaxis:{title:'t (ms)'},
        yaxis:{title:'Cai (mM)'},
        legend: { "orientation":"h", y:-0.2 },
        margin: margin,
    };

    var gcanbar_can = document.getElementById("gcanbar_can");
    var gbar_kmb = document.getElementById("gbar_kmb");

    gcanbar_can.disabled = true;
    gbar_kmb.disabled = true;

    gcanbar_can.value = "0.6";
    gbar_kmb.value = "0.005";

    send_parameters();


    Plotly.newPlot(plotlyChart_01, [{x:[0], y:[0]}], layout_01, {displayModeBar: false}, {responsive: true});
    Plotly.newPlot(plotlyChart_02, [{x:[0], y:[0]}], layout_02, {displayModeBar: false}, {responsive: true});

    resize_plots();

    $(window).resize(function(){
        console.log("Window Resize!");
        resize_plots();
    });

    $('#switch').on("change", function() {
        if ($('#switch')[0].checked) {
            gcanbar_can.disabled = false;
            gbar_kmb.disabled = false;
        } else {
            gcanbar_can.disabled = true;
            gbar_kmb.disabled = true;
            gcanbar_can.value = "0.6";
            gbar_kmb.value = "0.005";
            send_parameters();
        }
    });

    $('#run-train').click(function() {
        $('#plot-title')[0].innerHTML = "<h5>50hz train simulation</h5>";
        var xmin = 50;
        var xmax = 550;
        layout_01['xaxis']['autorange'] = false;
        layout_01['xaxis']['range'] = [xmin, xmax];
        Plotly.react(plotlyChart_01, [{x:[0], y:[0]}], layout_01);
        Plotly.react(plotlyChart_02, [{x:[0], y:[0]}], layout_02);

        var message = {"command" : "run_simulation"};
        message["parameters"] = {};
        for (var i = 0; i < 20; i++) {
            stim_item = "stim["+i+"]"
            message["parameters"][stim_item] = {"amp" : 0.03}
        }

        if ($('#switch')[0].checked) {
            send_parameters(use_default=false);  // update model parameters from GUI
        } else {
            send_parameters(use_default=true);   // use model's default parameter values
        }
        send_message(message);
    });



    $('#run-singleap').click(function() {
        $('#plot-title')[0].innerHTML = "<h5>Single AP simulation</h5>";
        var xmin=99;
        var xmax=106;
        layout_01['xaxis']['autorange'] = false;
        layout_01['xaxis']['range'] = [xmin, xmax];
        Plotly.react(plotlyChart_01, [{x:[0], y:[0]}], layout_01);
        Plotly.react(plotlyChart_02, [{x:[0], y:[0]}], layout_02);

        var message = {"command" : "run_simulation"};
        message["parameters"] = {};
        for (var i = 1; i < 20; i++) {
            stim_item = "stim["+i+"]"
            message["parameters"][stim_item] = {"amp" : 0.0}
        }

        if ($('#switch')[0].checked) {
            send_parameters(use_default=false);  // update model parameters from GUI
        } else {
            send_parameters(use_default=true);   // use model's default parameter values
        }
        send_message(message);
    });

    graph_callback = function(message) {
        var current_data = message.data;
        var current_data1 = current_data.slice(0,1)
        var current_data2 = current_data.slice(1);
        Plotly.react(plotlyChart_01, current_data1,layout_01);
        Plotly.react(plotlyChart_02,current_data2,layout_02);
    }

}

function send_message(msg) {
    ws.send(JSON.stringify(msg));
}

// solution for getting matching ids modified from
// http://stackoverflow.com/questions/3239598/how-can-i-get-the-id-of-an-element-using-jquery
function matched_ids(condition) {
    var retval = [];
    $(condition).each(function(){
        retval.push($(this).prop('id'));
    })
    return retval;
}

function send_parameters(use_default=false){
    var message = {"command" : "setfields"};
    if (use_default === false) {
        message["parameters"] = {"soma" : {}};
        var ids = matched_ids('.settings input');
        for (var i = 0; i < ids.length; i++) {
            message["parameters"]["soma"][ids[i]] = parseFloat($('#' + ids[i]).val());
        }
    }
    send_message(message);
}

function resize_plots(){
    var plotdiv = document.getElementById("collapsetitle");
    var plot_width = Math.trunc((plotdiv.offsetWidth-50)/2);

    var plotlyChart_01 = document.getElementById("plotlyChart_01");
    var plotlyChart_02 = document.getElementById("plotlyChart_02");

    var layout_01 = plotlyChart_01.layout;
    var layout_02= plotlyChart_02.layout;

    var data_01 = plotlyChart_01.data;
    var data_02= plotlyChart_02.data;

    layout_01["width"] = plot_width;
    layout_02["width"] = plot_width;

    Plotly.react(plotlyChart_01, data_01, layout_01);
    Plotly.react(plotlyChart_02, data_02, layout_02);
}


$(function() {
    if ('WebSocket' in window) {
        ws.onopen = function() {
            onready();

            // set the on-change event for all settings
            $('.settings input').change(function() {
                send_parameters();
            });
        };
        ws.onmessage = function (evt) {
            var message = JSON.parse(evt.data);
            // TODO: do things depending on message.command
            if (message.command == 'setgraph') {
                graph_callback(message);
            } else if (message.command == 'setfields') {
                var data = message.data;
                var keys = Object.keys(data);
                for (i = 0; i < keys.length; i++) {
                    $('#' + keys[i]).val(data[keys[i]]);
                }
            } else {
                console.log(message);
            }
        };
        ws.onclose = function() {
            document.write('Server connection lost; try refreshing the page.');
        };
    } else {
        document.write('Sorry, but this browser does not support websockets.');
    }
});
