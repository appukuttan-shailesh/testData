import neuron
from neuron import h
import numpy as np
from glob import glob as listdir
import os
from zipfile import ZipFile
from shutil import copyfile
from matplotlib import pyplot

h.load_file('stdrun.hoc')
h.init()
h.finitialize()

global v_vec

v_vec=[]

CVOde = h.cvode
CVOde.active(0)

h.celsius=34
Vrest=-80 #mV

h.v_init=Vrest

soma= h.Section(name='soma')
soma.diam=2
soma.L=3.5

#insert ion channels and set peak conductances

soma.insert('pas')
soma.e_pas=-65
soma.g_pas=1/float(30000)
soma.cm=1

soma.insert('naxj')
soma(0.5).ena=50
soma(0.5).gbar_naxj=0.12

soma.insert('kdr')
soma(0.5).ek=-80
soma(0.5).gkdrbar_kdr=0.001

soma.insert('kap')
soma(0.5).gkabar_kap=0.01

soma.insert('kmb')
soma(0.5).sh_kmb=-30
soma(0.5).gbar_kmb=0.005

soma.insert('can')
soma(0.5).gcanbar_can = 0.6

soma.insert('cacum')
soma(0.5).tau_cacum=500

soma.insert('kir')
soma(0.5).gkbar_kir=0.021

v = h.Vector()
v.record(soma(0.5)._ref_v)
t = h.Vector()
t.record(h._ref_t)
cai=h.Vector()
cai.record(soma(0.5)._ref_cai,sec=soma)

stim=[h.IClamp(.5, sec=soma) for i in range(20)]
for i in range(20):
    stim[i].delay=100+20*i #original 100+20*i
    stim[i].dur = 0.35
    stim[i].amp=0.00

soma=soma(0.5)
settings = {'tstop': 600, 'gkm':  0.005, 'gca': 0.6}
default_settings = dict(settings)
    
