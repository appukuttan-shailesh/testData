#!/bin/bash

set -e
set -x

module load /gpfs/bbp.cscs.ch/project/proj46/software/viz/local/share/modules/optframework-setup
#source /gpfs/bbp.cscs.ch/project/proj46/kozlov/software/pythonenv/bin/activate 

ipcontroller --ip='*' --quiet  \
  --HeartMonitor.period=10000 \
  --HeartMonitor.max_heartmonitor_misses=500 &
sleep 10
srun ipengine &
sleep 20

set +x

START=$(date +%s)
nrnivmodl ./mechanisms
python optimize.py
END=$(date +%s)
echo Time elapsed: $(($END - $START)) seconds.
