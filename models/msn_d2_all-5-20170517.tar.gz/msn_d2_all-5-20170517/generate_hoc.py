#!/usr/bin/env python

'''Example for generating a hoc template

 $ python generate_hoc.py > test.hoc

 Will save 'test.hoc' file, which can be loaded in neuron with:
     'load_file("test.hoc")'
 Then the hoc template needs to be instantiated with a morphology
     CCell("ignored", "path/to/morphology.swc")
'''
import json
import sys

from bluepyopt.ephys.models import CellModel
import cell_model

def main():
    '''main'''
    with open('best_parameters.json') as fp:
        param_values = json.load(fp)
    cell = cell_model.create()
    print cell.create_hoc(param_values)

if __name__ == '__main__':
    if '-h' in sys.argv or '--help' in sys.argv:
        print __doc__
    else:
        main()
