#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _bk_reg(void);
extern void _cadyn_reg(void);
extern void _cal12_reg(void);
extern void _cal13_reg(void);
extern void _caldyn_reg(void);
extern void _can_reg(void);
extern void _caq_reg(void);
extern void _car_reg(void);
extern void _cat32_reg(void);
extern void _cat33_reg(void);
extern void _kaf_reg(void);
extern void _kas_reg(void);
extern void _kdr_reg(void);
extern void _kdrf_reg(void);
extern void _kdrs_reg(void);
extern void _kir_reg(void);
extern void _kir21_reg(void);
extern void _kir23_reg(void);
extern void _kirin_reg(void);
extern void _kmf_reg(void);
extern void _kms_reg(void);
extern void _naf_reg(void);
extern void _nap_reg(void);
extern void _sk_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mechanisms/bk.mod");
    fprintf(stderr," mechanisms/cadyn.mod");
    fprintf(stderr," mechanisms/cal12.mod");
    fprintf(stderr," mechanisms/cal13.mod");
    fprintf(stderr," mechanisms/caldyn.mod");
    fprintf(stderr," mechanisms/can.mod");
    fprintf(stderr," mechanisms/caq.mod");
    fprintf(stderr," mechanisms/car.mod");
    fprintf(stderr," mechanisms/cat32.mod");
    fprintf(stderr," mechanisms/cat33.mod");
    fprintf(stderr," mechanisms/kaf.mod");
    fprintf(stderr," mechanisms/kas.mod");
    fprintf(stderr," mechanisms/kdr.mod");
    fprintf(stderr," mechanisms/kdrf.mod");
    fprintf(stderr," mechanisms/kdrs.mod");
    fprintf(stderr," mechanisms/kir.mod");
    fprintf(stderr," mechanisms/kir21.mod");
    fprintf(stderr," mechanisms/kir23.mod");
    fprintf(stderr," mechanisms/kirin.mod");
    fprintf(stderr," mechanisms/kmf.mod");
    fprintf(stderr," mechanisms/kms.mod");
    fprintf(stderr," mechanisms/naf.mod");
    fprintf(stderr," mechanisms/nap.mod");
    fprintf(stderr," mechanisms/sk.mod");
    fprintf(stderr, "\n");
  }
  _bk_reg();
  _cadyn_reg();
  _cal12_reg();
  _cal13_reg();
  _caldyn_reg();
  _can_reg();
  _caq_reg();
  _car_reg();
  _cat32_reg();
  _cat33_reg();
  _kaf_reg();
  _kas_reg();
  _kdr_reg();
  _kdrf_reg();
  _kdrs_reg();
  _kir_reg();
  _kir21_reg();
  _kir23_reg();
  _kirin_reg();
  _kmf_reg();
  _kms_reg();
  _naf_reg();
  _nap_reg();
  _sk_reg();
}
