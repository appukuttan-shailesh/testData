from cell import Neuron

junction_potential = 0.0

def demo(iapp):
    from neuron import h
    h.celsius = 35.0
    cell = Neuron()
    ic = h.IClamp(0.5, sec=cell.soma[0])
    ic.delay = 700
    ic.dur = 2000
    
    # setup recording
    t = h.Vector()
    t.record(h._ref_t)
    v = h.Vector()
    v.record(cell.soma[0](0.5)._ref_v)

    # procedure for doing each simulation
    def do_current_clamp_experiment(amp):   
        ic.amp = amp / 1000.
        h.finitialize(-86.4)
        h.fcurrent()
        h.dt = 0.0125
	cvode = h.CVode()
	cvode.active(1)
        tstop = 3000
	while h.t < tstop:
	    h.fadvance()
        return list(t), [mv - junction_potential for mv in v]

    # run the experiments, store the results
    results = []
    for amp in iapp:
        results.append(do_current_clamp_experiment(amp))
    
    return results

if __name__ == '__main__':
    #results = demo([-270, 50, 317, 367, 407])
    results = demo([-270, 50, 317, 368, 407])

    with open("vm.out", "w") as out:
        for time, voltage in results:
            for t, v in zip(time, voltage):
	        out.write("%g %g\n" % (t, v))
            out.write("\n\n")
    print 'voltage traces saved to vm.out'

    try:
        import matplotlib.pyplot as plt
        for time, voltage in results:
            plt.plot(time, voltage)
	plt.show()
    except ImportError:
	print 'no matplotlib available' 

