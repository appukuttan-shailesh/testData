import bluepyopt as bpopt
import bluepyopt.ephys as ephys


morphology = ephys.morphologies.NrnFileMorphology(
    'morphology/WT-P270-20-14ak.swc',
    do_replace_axon=True)

import cell_model
parameters = cell_model.define_parameters('parameters.json')
#for x in parameters: print x

mechanisms = cell_model.define_mechanisms('mechanisms.json')

cell = ephys.models.CellModel(
    'msn_d1', 
    morph=morphology, 
    mechs=mechanisms, 
    params=parameters)

opt_params = [p.name for p in cell.params.values() if not p.frozen]
#for x in opt_params: print x

import cell_evaluator
protocols = cell_evaluator.define_protocols('protocols.json')

calculator = cell_evaluator.define_fitness_calculator(
    protocols, 
    'features.json')

simulator = ephys.simulators.NrnSimulator()

evaluator = ephys.evaluators.CellEvaluator(
    cell_model=cell,
    param_names=opt_params,
    fitness_protocols=protocols,
    fitness_calculator=calculator,
    sim=simulator)

offspring_size = 6 # 50 # 200
ngenerations = 3 # 30 # 100                                   

#from ipyparallel import Client
#rc = Client()
#lview = rc.load_balanced_view()
#
#optimiser = bpopt.optimisations.DEAPOptimisation(
#    evaluator=evaluator,
#    offspring_size=offspring_size,
#    map_function=lview.map_sync)

optimiser = bpopt.optimisations.DEAPOptimisation(
    evaluator=evaluator,
    offspring_size=offspring_size)

final_pop, halloffame, log, hist = optimiser.run(max_ngen=ngenerations)
print log

best_params = evaluator.param_dict(halloffame[0])
#for x in best_params: print x, best_params[x]

import json
with open('best_params.json', 'w') as fp:
    json.dump(best_params, fp, indent=4, sort_keys=True)

#best_responses = evaluator.run_protocols(
#    protocols=protocols.values(), 
#    param_values=best_params)
#print best_responses
